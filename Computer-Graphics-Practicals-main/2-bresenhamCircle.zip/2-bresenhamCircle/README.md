# PRACTICAL 2
**Write a program to implement mid-point circle drawing algorithm.**

## OUTPUT
`Compilation`
<p align="center">
<img src="https://user-images.githubusercontent.com/68191677/219386379-49a1ed13-d48a-4545-b06f-82f2765d99c4.png"  />
</p>

`Mid-point circle drawing algorithm`
<p align="center">
<img src="https://user-images.githubusercontent.com/68191677/219386214-3a8fe91f-371f-4903-9d8c-7f4e969cbf5d.png"  />
</p>